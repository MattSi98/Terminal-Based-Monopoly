open OUnit2

let suite = "test suite" >::: []

let _ = run_test_tt_main suite