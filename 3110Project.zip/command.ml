open State
open Property

type check = 
  | MoneyCheck
  | PropertyCheck
  | BoardCheck

type command = 
  | Roll of int
  | BuyProperty
  | PassProperty
  | BuyHouses of int * Property.t
  | SellHouses of int * Property.t
  | Mortgage of Property.t
  | Unmortgage of Property.t
  | Pay
  | Check of check
  | Trade of Player.t
  | EndTurn
  | DeclareBankruptcy



exception Invalid_command
exception Wrong_phase_command


let random_num () = Random.self_init (); (Random.int 11) + 2

(*************************************PARSER*************************************)
(** [command_builder state tokens] is the command that [tokens] specify in [state] 
    Raises: Invalid_command if there is no such command*)
let command_builder state tokens = 

  if List.hd tokens = "roll" then
    if List.length tokens = 1 then Roll (random_num ())
    else if List.length tokens = 2 then 
      try Roll (int_of_string (List.nth tokens 1)) with | _ -> raise Invalid_command
    else raise Invalid_command

  else if tokens |> String.concat " " = "buy" then BuyProperty

  else if tokens |> String.concat " " = "pass" then PassProperty


  else if Str.string_match (Str.regexp {|buy [1-5] \(house\|houses\) on [.]*|}) 
      (tokens |> String.concat " ") 0 then 
    (* returns the list of tokens containing the property name *)
    try
      let rec helper = function
        | [] -> failwith "impossible case"
        | h::t -> if h = "on" then t else helper t in

      BuyHouses (int_of_string (List.nth tokens 1), 
                 tokens |> helper |> String.concat " " |> State.get_property state)
    with
    |Failure _ -> raise Invalid_command

  else if Str.string_match (Str.regexp {|sell [1-5] \(house\|houses\) on [.]*|}) 
      (tokens |> String.concat " ") 0 then 
    (* returns the list of tokens containing the property name *)
    try
      let rec helper = function
        | [] -> failwith "impossible case"
        | h::t -> if h = "on" then t else helper t in

      SellHouses (int_of_string (List.nth tokens 1), 
                  tokens |> helper |> String.concat " " |> State.get_property state)
    with
    |Failure _ -> raise Invalid_command

  else if List.hd tokens = "mortgage" && List.length tokens > 1 then 
    try 
      Mortgage ((match tokens with | [] -> failwith "impossible case" | h::t -> t) |> 
                String.concat " " |> State.get_property state)
    with
    | Failure _ -> raise Invalid_command


  else if List.hd tokens = "unmortgage" && List.length tokens > 1 then 
    try 
      Unmortgage ((match tokens with | [] -> failwith "impossible case" | h::t -> t) |> 
                  String.concat " " |> State.get_property state)
    with
    | Failure _ -> raise Invalid_command


  else if tokens |> String.concat " " = "pay" then Pay

  else if tokens |> String.concat " " = "check money" then Check MoneyCheck

  else if tokens |> String.concat " " = "check properties" then Check PropertyCheck

  else if tokens |> String.concat " " = "end turn" then EndTurn

  else if tokens |> String.concat " " = "declare bankruptcy" then DeclareBankruptcy

  else if tokens |> String.concat " " = "quit" then exit 0

  else raise Invalid_command



(********************************COMMAND EXECUTORS******************************)
(** [sell_houses_command_executor state command] is (state', msg) where state' is [state] after
    [command] has been executed, and msg is an appropriate msg saying what actions
    have been done 
    Requires: [command] is [SellHouses] command and [state] is in phase 
    [Rolling], [Landing Buy], [Landing Pay], or [Final]
    Raises: Failure if precondition is violated*)
let sell_houses_command_executor state command = 
  match state |> get_phase with
  | Rolling | Landing Buy _ | Landing Pay _ | Final -> 
    (match command with
     | SellHouses (num, property) -> 
       (try (State.sell_houses state (state |> State.get_current_player) property num,
             "You sold " ^ string_of_int num ^ " houses on " ^ (property |> get_name))
        with | Failure _ -> (state, "You can't do that, try something else"))
     | _ -> failwith "sell_houses_command_executor precondition violated")
  | _ -> failwith "sell_houses_command_executor precondition violated"

(** [mortgage_command_executor state command] is (state', msg) where state' is [state] after
    [command] has been executed, and msg is an appropriate msg saying what actions
    have been done 
    Requires: [command] is [Mortgage] command and [state] is in phase 
    [Rolling], [Landing Buy], [Landing Pay], or [Final]
    Raises: Failure if precondition is violated*)
let mortgage_command_executor state command = 
  match state |> get_phase with
  | Rolling | Landing Buy _ | Landing Pay _ | Final -> 
    (match command with
     | Mortgage property -> 
       (try (mortgage state (state |> State.get_current_player) property,
             "You mortgaged " ^ (property |> get_name))
        with | Failure _ -> (state, "You can't do that, try something else"))
     | _ -> failwith "mortgage_command_executor precondition violated")
  | _ -> failwith "mortgage_command_executor precondition violated"


(** [unmortgage_command_executor state command] is (state', msg) where state' is [state] after
    [command] has been executed, and msg is an appropriate msg saying what actions
    have been done 
    Requires: [command] is [Unmortgage] command and [state] is in phase 
    [Rolling], or [Final]
    Raises: Failure if precondition is violated*)
let unmortgage_command_executor state command = 
  match state |> get_phase with
  | Rolling | Final -> 
    (match command with
     | Unmortgage property -> 
       (try (unmortgage state (state |> State.get_current_player) property,
             "You unmortgaged " ^ (property |> get_name))
        with | Failure _ -> (state, "You can't do that, try something else"))
     | _ -> failwith "unmortgage_command_executor precondition violated")
  | _ -> failwith "unmortgage_command_executor precondition violated"


(** [rolling_command_executor state command num] is (state', msg) where state' is [state] after
    [command] has been executed, and msg is an appropriate msg saying what actions
    have been done 
    Requires: command is a [Roll] command and state is in the [Rolling] phase
    Raises: Failure if precondition is violated*)
let rolling_command_executor state command =
  match state |> get_phase with
  | Rolling -> 
    (match command with
     | Roll num -> 
       let state' = move_player state (state |> get_current_player) num in
       (match state' |> get_phase with
        | Landing Buy property ->
          (state', "You rolled a " ^ string_of_int num ^ " and landed on " ^ 
                   (property |> get_name) ^ ", would you like to buy or pass?")

        | Landing Pay (property, owner, amt) ->
          (match owner with 
           | Some player -> 
             (state', "You rolled a " ^ string_of_int num ^ " and landed on " ^ 
                      (property |> get_name) ^ ", you must pay " ^ 
                      (player |> Player.get_name) ^ " $" ^
                      string_of_int amt)
           | None -> 
             (state', "You rolled a " ^ string_of_int num ^ " and landed on " ^ 
                      (property |> get_name) ^ ", you must pay $" ^ 
                      string_of_int amt))

        | Landing Nil property -> 
          (match property with
           | Commercial ct -> 
             (match ct with
              | Colored info -> 
                (state' |> move_to_final_phase, 
                 "You rolled a " ^ string_of_int num ^ " and landed on " ^ 
                 (property |> get_name) ^ ", there is nothing to do")
              | Railroad info -> 
                (state' |> move_to_final_phase, 
                 "You rolled a " ^ string_of_int num ^ " and landed on " ^ 
                 (property |> get_name) ^ ", there is nothing to do")
              | Utility info -> 
                (state' |> move_to_final_phase, 
                 "You rolled a " ^ string_of_int num ^ " and landed on " ^ 
                 (property |> get_name) ^ ", there is nothing to do"))
           | NonCommercial nct -> 
             (match nct with
              | Go (name, amt) -> 
                (state' |> move_to_final_phase, 
                 "You rolled a " ^ string_of_int num ^ " and landed on " ^ 
                 (property |> get_name) ^ ", unimplemented")
              | Tax (name, amt) -> failwith "impossible case roll_executor"
              | Jail (name, player_indices) -> 
                (state' |> move_to_final_phase, 
                 "You rolled a " ^ string_of_int num ^ " and landed on " ^ 
                 (property |> get_name))
              | FreeParking name -> 
                (state' |> move_to_final_phase, 
                 "You rolled a " ^ string_of_int num ^ " and landed on " ^ 
                 (property |> get_name))
              | GoJail name -> 
                (state' |> move_to_final_phase, 
                 "You rolled a " ^ string_of_int num ^ " and landed on " ^ 
                 (property |> get_name) ^ ", unimplemented")
              | CCC name -> 
                (state' |> move_to_final_phase, 
                 "You rolled a " ^ string_of_int num ^ " and landed on " ^ 
                 (property |> get_name) ^ ", unimplemented")))

        | _ -> failwith "impossible case roll_executor")
     | _ -> failwith "rolling_command_exectuer precondition violated")
  | _ -> failwith "rolling_command_exectuter precondition violated"

(** [check_command_executor state command] is (state', msg) where state' is [state] after
    [command] has been executed, and msg is an appropriate msg saying what actions
    have been done 
    Requires : [state] phase is either Rolling, Landing Pay, Landing Buy, or Final 
    [command] is a Check command
    Raises: Failure if precondition violated*)
let check_command_executor state command = 
  match state |> get_phase with 
  | Rolling | Landing Pay _ | Landing Buy _ | Final -> 
    (match command with
     | Check check -> 
       (match check with
        | MoneyCheck -> (state, "You have $" ^ 
                                (state |> get_current_player |> Player.get_money
                                 |> string_of_int))
        | PropertyCheck -> (state, "You own:\n" ^ 
                                   (state |> get_current_player |> 
                                    get_players_properties state |> 
                                    List.map get_name |> String.concat "\n"))
        | BoardCheck -> failwith "Unimplemented")
     | _ -> failwith "check_command_executor precondition violated")
  | _ -> failwith "check_command_executor precondition violated"


(** [buy_houses_command_executor state command] is (state', msg) where state' is [state] after
    [command] has been executed, and msg is an appropriate msg saying what actions
    have been done
    Requries: [state] is in phase [Rolling] or [Final] and [command] is the [BuyHouses] command
    Raises: Failure if precondition is violated *)
let buy_houses_command_executor state command = 
  match state |> get_phase with
  | Rolling | Final -> 
    (match command with
     | BuyHouses (num, property) -> 
       (try (State.buy_houses state (state |> get_current_player) property num,
             "You bought " ^ string_of_int num ^ " houses on " ^ (property |> get_name))
        with
        | Failure _ -> (state, "You can't do that, try something else"))
     | _ -> failwith "buy_houses_command_executor precondition violated")
  | _ -> failwith "buy_houses_command_executor precondition violated"


(** [buy_property_command_executor state command]  is (state', msg) where state' is [state] after
      [command] has been executed, and msg is an appropriate msg saying what actions
      have been done
      Requries: [state] is in phase Landing Buy and [command] is a BuyProperty command
      Raises: Failure if precondition is violated*)
let buy_property_command_executor state command = 
  match state |> get_phase with
  | Landing Buy property -> 
    (match command with
     | BuyProperty -> 
       (try (buy_property state property (state |> get_current_player),
             "You bought " ^ (property |> get_name) ^ "!") with 
       | Failure _ -> (state, "You don't have enough money, try something else"))
     | _ -> failwith "buy_property_command_executor precondition violated")
  | _ -> failwith "buy_property_command_executor precondition violated"

(** [pass_property_command_executor state command]  is (state', msg) where state' is [state] after
      [command] has been executed, and msg is an appropriate msg saying what actions
      have been done
      Requries: [state] is in phase Landing Buy and [command] is a PassProperty command
      Raises: Failure if precondition is violated*)
let pass_property_command_executor state command = 
  match state |> get_phase with
  | Landing Buy property -> 
    (match command with
     | PassProperty -> 
       (state |> move_to_final_phase, "unimplemented auction phase, moved to final phase")
     | _ -> failwith "pass_property_command_executor precondition violated")
  | _ -> failwith "pass_property_command_executor precondition violated"

(** [pay_command_executor state command] is (state', msg) where state' is [state] after
      [command] has been executed, and msg is an appropriate msg saying what actions
      have been done
      Requries: [state] is in phase Landing Pay and [command] is a Pay command
      Raises: Failure if precondition is violated*)
let pay_command_executor state command = 
  match state |> get_phase with
  | Landing Pay (property, reciever, amt) -> 
    (match command with
     | Pay -> 
       (try 
          (match reciever with
           | Some player -> 
             (pay state (state |> get_current_player) reciever amt,
              "You paid $" ^ (string_of_int amt) ^" to "
              ^(Player.get_name player)^".")
           | None -> (pay state (state |> get_current_player) reciever amt,
                      "You paid $" ^ (string_of_int amt)^" in taxes."))
        with 
        | Failure _ -> (state, "You don't have enough money, try something else"))
     | _ -> failwith "pay_command_executor precondition violated")
  | _ -> failwith "pay_command_executor precondition violated"


(** [declare_bankruptcy_command_executor state command] is (state', msg) where state' is [state] after
      [command] has been executed, and msg is an appropriate msg saying what actions
      have been done
      Requries: [state] is in phase Landing Pay and [command] is a DeclareBankruptcy command
      Raises: Failure if precondition is violated*)
let declare_bankruptcy_command_executor state command = 
  match state |> get_phase with
  | Landing Pay _ -> 
    (match command with
     | DeclareBankruptcy -> 
       (set_player_bankrupt state (state |> get_current_player), 
        (state |> get_current_player |> Player.get_name) ^ " declared bankruptcy!")
     | _ -> failwith "declare_bankruptcy_command_executor precondition violated")
  | _ -> failwith "declare_bankruptcy_command_executor precondition violated"


(** [end_turn_command_executor state command] is (state', msg) where state' is [state] after
      [command] has been executed, and msg is an appropriate msg saying what actions
      have been done
      Requries: [state] is in phase Final and [command] is a EndTurn 
      Raises: Failure if precondition is violated*)
let end_turn_command_executor state command = 
  match state |> get_phase with
  | Final -> 
    (match command with
     | EndTurn -> 
       (state |> next_turn, "")
     | _ -> failwith "end_turn_command_executor precondition violated")
  | _ -> failwith "end_turn_command_executor precondition violated"



(********************************PHASE EXECUTORS **********************************)
(** [roll_phase_executor state command] is (state', msg) where state' is [state] after
    [command] has been executed, and msg is an appropriate msg saying what actions
    have been done
    Requries: [state] is in phase [Rolling]
    Raises: Failure if precondition is violated*)
let roll_phase_executor state command = 
  match state |> get_phase with
  | Rolling -> 
    (match command with
     | Roll _ -> rolling_command_executor state command 
     | BuyHouses _ -> buy_houses_command_executor state command
     | SellHouses _ -> sell_houses_command_executor state command
     | Mortgage _ -> mortgage_command_executor state command
     | Unmortgage _ -> unmortgage_command_executor state command
     | Trade _ -> failwith "Unimplemented"
     | Check _ -> check_command_executor state command 
     | _ -> raise Wrong_phase_command)
  | _ -> failwith "roll_phase_executor precondition violated"


(** [landing_buy_phase_executor state command] is (state', msg) where state' is [state] after
    [command] has been executed, and msg is an appropriate msg saying what actions
    have been done
    Requries: [state] is in phase Landing Buy
    Raises: Failure if precondition is violated*)
let landing_buy_phase_executor state command = 
  match state |> get_phase with
  | Landing Buy _ -> 
    (match command with
     | BuyProperty -> buy_property_command_executor state command
     | PassProperty -> pass_property_command_executor state command
     | Mortgage _ -> mortgage_command_executor state command
     | SellHouses _ -> sell_houses_command_executor state command
     | Check _ -> check_command_executor state command
     | _ -> raise Wrong_phase_command)
  | _ -> failwith "landing_buy_phase_executor precondition violated"


(** [landing_pay_phase_executor state command] is (state', msg) where state' is [state] after
    [command] has been executed, and msg is an appropriate msg saying what actions
    have been done
    Requries: [state] is in phase Landing Pay
    Raises: Failure if precondition is violated*)
let landing_pay_phase_executor state command = 
  match state |> get_phase with
  | Landing Pay _ -> 
    (match command with
     | Pay -> pay_command_executor state command
     | DeclareBankruptcy -> declare_bankruptcy_command_executor state command
     | Mortgage _ -> mortgage_command_executor state command
     | SellHouses _ -> sell_houses_command_executor state command
     | Check _ -> check_command_executor state command
     | _ -> raise Wrong_phase_command)
  | _ -> failwith "landing_pay_phase_executor precondition violated"


(** [final_phase_executor state command] is (state', msg) where state' is [state] after
    [command] has been executed, and msg is an appropriate msg saying what actions
    have been done
    Requries: [state] is in phase Final
    Raises: Failure if precondition is violated*)
let final_phase_executor state command = 
  match state |> get_phase with
  | Final -> 
    (match command with
     | Trade _ -> failwith "Unimplemented"
     | BuyHouses _ -> buy_houses_command_executor state command
     | SellHouses _ -> sell_houses_command_executor state command
     | Mortgage _ -> mortgage_command_executor state command
     | Unmortgage _ -> unmortgage_command_executor state command
     | Check _ -> check_command_executor state command
     | EndTurn -> end_turn_command_executor state command
     | _ -> raise Wrong_phase_command)
  | _ -> failwith "final_phase_executor precondition violated"



(*********************************DELEGATORS************************************)
(** [command_executor state command] is (state', msg) where state' is [state] after
    [command] has been executed, and msg is an appropriate msg saying what actions
    have been done
    Requires: [state] is not in phase Landing Nil
    Raises: Failure if precondition is violated*)
let command_executor state command =
  match state |> State.get_phase with
  | Rolling -> roll_phase_executor state command
  | Landing Buy _ -> landing_buy_phase_executor state command 
  | Landing Pay _ -> landing_pay_phase_executor state command 
  | Landing Nil _ -> failwith "command_executor precondition violated"
  | Auction _ -> failwith "Unimplemented" 
  | Trading _ -> failwith "Unimplemented"
  | Final ->  final_phase_executor state command


let command_parser state str = 
  let tokens = str |> Str.split (Str.regexp "[ \t]+") |> 
               List.map (fun e -> e |> String.lowercase_ascii) in

  try tokens |> command_builder state |> command_executor state with
  | Invalid_command -> (state, "Please enter a valid command")
  | Wrong_phase_command -> (state, "You can't do that in this phase of your turn")



