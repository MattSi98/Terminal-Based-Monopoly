open State
open Player
open Property

type command = 
  | Roll
  | Pass
  | End_turn
  | Quit
  | Pay_tax
  | Buy of Property.t
  | Purchase of Property.t
  | Properties of Player.t
  | Money of string
  | Pay_rent
  | Bankruptcy of Player.t

exception NoCommand

exception InvalidCommand

exception IncompatibleCommand

(** [get_tax property] is the tax associated wuth [property] if the property 
    is a NonCommercial Tax property. Else raises IncompatoibleCommand. *)
let get_tax property = 
  match property with 
  | Commercial c -> raise IncompatibleCommand
  | NonCommercial n -> begin 
      match n with 
      | Tax (name,tax) -> tax
      | _ -> raise IncompatibleCommand
    end 

(** [get_prop_name property] is the name of [property]. *)
let get_prop_name property =
  match property with 
  | Commercial c -> begin
      match c with 
      | Colored info -> info.name
      | Railroad info -> info.name
      | Utility info -> info.name
    end
  | NonCommercial n -> begin 
      match n with 
      | Go (name, go_bonus) -> name
      | Tax (name,tax) -> name
      | GoJail name -> name
      | Jail (name, players) -> name 
      | CCC name -> name
      | FreeParking name -> name
    end 
(** [prop_is_tax property] is true if [property] is NonCommercial Tax.
    False otherwise. *)
let prop_is_tax property = 
  match property with 
  | NonCommercial Tax (name,tax) -> true
  | _ -> false 

let pay_rent state = 
  let player = State.get_current_player state in
  let property = State.get_location state player in
  let owner_and_amt  = match State.get_phase state with
    | Landing (Pay (property,owner,amt)) ->  (owner,amt)
    | _ -> (None,0) in
  let owner = match fst owner_and_amt with
    | Some owner -> owner
    | None -> raise IncompatibleCommand in
  let rent = snd owner_and_amt in
  if (Property.is_commercial property = true) then
    if (State.can_pay_cash player rent) then
      let new_state =
        State.pay state player (Some owner) rent in 
      let message = "You paid "^(Player.get_name (owner))
                    ^" $"^(string_of_int rent)^" in rent." in
      (new_state, message)
    else 
    if (State.can_pay_total state player rent) then
      (state, "You don't have enough money to pay the rent! 
      You need to raise enough cash to pay the tax.")
    else 
      (state, "It appears that it is impossible for you to raise enough
               money to pay the rent. Time to declare bankruptcy?")
  else raise IncompatibleCommand

(** [pay_tax state] is the tuple (new_state, message) where message is the 
    message to be printed that informs the player that they have paid the tax
    and new_state is the state that results from paying the tax. If the player
    does not have enough cash or total value to pay the tax then the tuple
    (state,msg) is returned where state is the old state and msg is a message
    that informs the player that they can't afford to pay the tax. *)
let pay_tax state =
  let player = State.get_current_player state in
  let property = State.get_location state player in
  let tax = get_tax property in
  if (prop_is_tax property) then 
    if (State.can_pay_cash player tax) then
      let new_state =  State.pay state player None tax in 
      let message = "You paid "^
                    string_of_int tax^" in taxes!" in 
      (new_state,message)
    else 
    if (State.can_pay_total state player tax) then
      (state, "You don't have enough money to pay the tax! 
      You need to raise enough cash to pay the tax.")
    else 
      (state, "It appears that it is impossible for you to raise enough
               money to pay the tax. Time to declare bankruptcy?")
  else raise IncompatibleCommand

(** [roll_tax state property player message] is the tuple (state,message_tax)
    where message is the message to be printed that informs the player that
    they must pay a tax. *)
let roll_tax state property player message amt = 
  let tax = amt in 
  let message_tax = message^"\nYou need to pay "^
                    string_of_int tax^" in taxes!" in 
  (state,message_tax)

(** [roll_nil state property message] is the tuple (new_state,message)
    where message is the message to be printed and new_state is the new state
    that results from landing on a non-commercial and is non-tax property. *)
let roll_nil state property message = 
  let state_nil = State.next_turn state in 
  let message_nil = 
    message^"\n"^(get_prop_name property)^" is not implemented yet." in
  (state_nil, message_nil)
(* Note that in future other actions besides just advancing to next turn
   might be implemented. Actions such as collecting 200 if passed/on go.*)

(** [roll_pay state property owner message] is the tuple (new_state,message)
    where message is the message to be printed and new_state is the new state
    that results from landing on a commercial Property that is already owned
    by some player [owner]. *)
let roll_pay state property owner amt message = 
  let message_pay = 
    message^"\nYou need to pay $"^(string_of_int amt)^" to "^
    (Player.get_name owner)^" in rent." in
  (state,message_pay)

(** [roll state] is the tuple (new_state,message) where message is the message
    to be printed and new_state is the new state that results from rolling for
    the current player as indicated by the inputed [state]. If the state is 
    not in the [Roll] phase then [new_state] is [state] and [message] is a
    message that informs the player that they are not in the roll phase of
    their turn. *)
let roll state  = 
  if (State.get_phase state) = Roll then
    let n = Random.self_init ();(Random.int 11) + 2 in 
    let new_state = State.move_player state (State.get_current_player state) n in
    let player = State.get_current_player new_state in
    let player_name = Player.get_name player in 
    let message = 
      player_name^" rolled "^(string_of_int n)^" and is now on "^
      (player |> State.get_location new_state |> get_prop_name) in 
    match State.get_phase new_state with
    | Landing (Pay (property,owner,amt)) when owner = None ->
      roll_tax new_state property player message amt
    | Landing (Pay (property, Some owner,amt)) ->
      roll_pay new_state property owner amt message
    | Landing (Nil property)-> roll_nil new_state property message
    | _ -> (new_state,message^"\nYou can 'buy' this property or 'pass'.")
  else 
    (state, "You can't roll in this phase of your turn.")

(** [pass state] is the tuple (new_state,message) where message is the
    message to be printed and new_state is the new state that results from
    the player passing on purchasing the property they landed on and thus
    moving to the next turn. Usually called when player decides not to purchase
    a property they landed on. *)
let pass state = 
  if State.get_phase state = 
     Landing (Buy (State.get_current_player state |> State.get_location state))
  then 
    let new_state = State.next_turn state in 
    let message = 
      "It is now "^(
        new_state
        |> State.get_current_player
        |> Player.get_name)
      ^"'s turn." in
    (new_state,message)
  else raise IncompatibleCommand

(** [end_turn state] is the tuple (new_state,message) where message is the
    message to be printed and new_state is the new state that results from
    the player ending their turn. If the player is not in the right phase
    (state,message) is returned where the message alerts the player that 
    they can't end their turn during the current phase. *)
let end_turn state = 
  if State.get_phase state = Final then
    let new_state = State.next_turn state in 
    let message = 
      "It is now "^(
        new_state
        |> State.get_current_player
        |> Player.get_name)
      ^"'s turn." in
    (new_state,message)
  else (state, "You can not end your turn in this phase of your turn!")

(** [buy state property] is the tuple (new_state,message) where message is the
    message to be printed and new_state is the new state that results from 
    the current player in [state] purchasing [property] if they can afford it.
    Otherwise new_state is [state] and [message] is a message that informs
    the player that they can't afford the property.*)
let buy state property =
  if State.get_phase state = Roll then (state,"You must roll first.") 
  else
    let current_player = State.get_current_player state in 
    let price = Property.get_price property in 
    if (State.can_pay_cash current_player price) then
      let new_state = State.buy_property state property current_player in 
      let message = "You bought "^
                    (get_prop_name property)^" for $"^
                    string_of_int price^"!" in 
      (new_state,message)
    else
    if (State.can_pay_total state current_player price) then 
      (state,"You fon't have enough cash to buy "^
             (State.get_location state current_player |> get_prop_name)^"!")
    else 
      (state, "It appers there is no way to raise the cash you need to buy
      this property.")

(** [print_properties state player] is the tuple (state,message) where message
    is the message to be printed that lists the property's owned by [player]. *)
let print_properties state player = 
  let prop_list = State.get_players_properties state player in
  let prop_name_list = List.map get_prop_name prop_list in 
  let message = List.fold_left (fun acc x -> acc^"\n"^x) "" prop_name_list in 
  (state,(Player.get_name player)^"'s Properties:"^message^"\n")

(** [money state amt] is the tuple (state,message) where message is the
    message to be printed that informs the player of how much money they
    have and state is the same state that was passed in. *)
let money state amt = 
  let message = 
    "You ("
    ^(State.get_current_player state |> Player.get_name)
    ^") have $"^amt^"." in 
  (state,message)

(** [bankruptcy state player] is the tuple (new_state,message) where message 
    is the message to be printed that informs the player that they have
    declared bankruptcy and new_state is the new state that results from
    [player] declaring bankruptcy. *)
let bankruptcy state player = 
  let new_state = State.set_player_bankrupt state player in 
  let message = (Player.get_name player)^" has declared bankruptcy!" in 
  (new_state,message)

(* PARSING FUNCTIONS: *)

(** [command_builder_aux state prev user_str] is the command that corresponds
    to the user input [user_str]. Handles 2 word commands by evaluating the
    string prior to a space in the user input [prev]. Raises [InvalidCommand]
     if [user_str] does not correspond to any command. *)
let rec command_builder_aux state prev = function
  | "roll" when prev = "" -> Roll
  | "pass" when prev = "" -> Pass
  | "quit" when prev = "" -> Quit
  | "turn" when prev = "end" -> End_turn
  | "tax" when prev = "pay" -> Pay_tax
  | "buy" when prev = "" -> 
    Buy (State.get_current_player state |> State.get_location state) 
  | "properties" when prev = "my" -> 
    Properties (state |> State.get_current_player)
  | "money" when prev = "my" ->
    Money (state |> State.get_current_player |> Player.get_money |> string_of_int)
  | "rent" when prev = "pay"-> Pay_rent
  | "bankruptcy" when prev = "declare" ->
    Bankruptcy (state |> State.get_current_player)
  | _ -> raise InvalidCommand

(** [command_builder state user_input] is the command that results from the 
    raw user input [user_input]. Raises NoCommand if [user_input] is the empty
    string. Raises [InvalidCommand] if [user_input] does not correspond to any
    command. *)
let command_builder state user_input = 
  match user_input with  
  | ""::t -> raise NoCommand
  | h::t when List.length user_input = 1  ->
    command_builder_aux state "" h
  | h::h'::t when List.length user_input = 2  ->
    command_builder_aux state h h'
  | _ -> raise InvalidCommand

(** [command_executer state command] is the (new_state,message) that results
    from executing the functionality associated with the given [command]. *)
let command_executer state = function
  | Roll -> roll state 
  | Pass -> pass state
  | End_turn -> end_turn state
  | Quit -> exit 0
  | Pay_tax -> pay_tax state
  | Buy property -> buy state property
  | Properties player-> print_properties state player 
  | Money amt -> money state amt
  | Pay_rent -> pay_rent state
  | Bankruptcy player -> bankruptcy state player
  | _ -> (state,"Something went wrong in Command.command_executer")

(** [check_command_with_phase state command] ensures that [command] is 
    compatible with the current phase of the [state]. *)
let check_command_with_phase state command = 
  let phase = State.get_phase state in 
  (* In the pattern match check that the command is allowed during that phase.*)
  match phase with 
  | State.Roll -> command_executer state command
  | Landing scenario -> command_executer state command
  | Auction -> command_executer state command
  | Final -> command_executer state command

let command_parser state user_input = 
  try 
    String.trim user_input
    |> String.split_on_char ' '
    |> List.map String.lowercase_ascii 
    |> command_builder state
    |> check_command_with_phase state
  with 
  | InvalidCommand -> (state, "Please enter a valid command.")
  | NoCommand -> (state, "Please enter a command.")
  | IncompatibleCommand -> (state, "You can't use that command during this
   phase of your turn.")
