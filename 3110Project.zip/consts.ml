let num_players = 3
let num_spaces = 40
let starting_money = 500
let go_money = 200
let tax_money = 150
